//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- HEADERS =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- STRUCT =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

typedef struct donations { // Structure declaration
	char supname[50]; // Member (char variable) (size = 50)
	char supcode[4]; // Member (char variable) (size = 4)
	char donator[30]; // Member (char variable) (size = 30)
	int no_shipment; // Member (int variable)
	float quantity_received; // Member (float variable)
}donations;

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- FUNCTION: SEARCH =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

void searchdonation() {
	donations h1;
	FILE* fp = fopen("donations.txt", "r"); 
	char supcode[40];
	int found=0;
	printf("Enter supply code to search: ");
	scanf("%s", &supcode);
	while (fread(&h1, sizeof(donations), 1, fp))
	{
		if ((strcmp(h1.supcode, supcode)) == 0) {
			found = 0;
			printf("%-40s%-20s%-20s%-20d%-20f\n", h1.supname, h1.supcode, h1.donator, h1.no_shipment, h1.quantity_received);
		}
	}
	fclose(fp);
}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- FUNCTION: CREATE RECORD =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

void createrecord(){
	donations h;
	FILE* fp = fopen("donations.txt", "a+");
	
	printf("Enter supply name: ");
	scanf("%s", h.supname);

	printf("Enter supply code: ");
	scanf("%s", h.supcode);

	printf("Enter donator name: ");
	scanf("%s", h.donator);

	printf("Enter number of shipment: ");
	scanf("%d", &h.no_shipment);

	printf("Enter quantity: ");
	scanf("%f", &h.quantity_received);

	fwrite(&h, sizeof(donations), 1, fp); //writing inputed input into donations.txt

	
	fclose(fp);
}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- FUNCTION: UPDATE DONATION QUANTITY =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

void update_donation() {
	donations h1;
	FILE* fp = fopen("donations.txt", "a+");
	FILE* fp1 = fopen("temp.txt", "w");
	char supcode[40];
	float quantity_received = 0.0;
	int no_shipment = 0;
	int found = 0;
	printf("Enter supply code to update it: ");
	scanf("%s", &supcode);
	while (fread(&h1, sizeof(donations), 1, fp))
	{
		if ((strcmp(h1.supcode, supcode)) == 0) {
			found = 0;
			printf("Enter supply name: ");
			scanf("%s", h1.supname);
			printf("Enter supply code: ");
			scanf("%s", h1.supcode);
			printf("Enter donator name: ");
			scanf("%s", h1.donator);
			printf("Enter number of shipment: ");
			scanf("%d", &h1.no_shipment);
			printf("Enter NEW quantity: ");
			scanf("%f", &h1.quantity_received);
			fwrite(&h1, sizeof(donations), 1, fp); //writing inputed input into donations.txt

		}
	}
	fclose(fp);
	fclose(fp1);
	if (found) {
		fp1 = fopen("temp.txt", "r");
		fp = fopen("donations.txt", "w");

		while(fread(&h1, sizeof(supcode), 1, fp1)) {
			fwrite(&h1, sizeof(supcode), 1, fp);
			break;
		}

		fclose(fp);
		fclose(fp1);
	}

		
}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- FUNCTION: ADD/EDIT DISTRIBUTION QUANTITY =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

struct distribution {
	char supcode[3]; // Member (char variable) (size=3)
	float dist_quantity;// Member (float variable) 
};

void distcreate() {
	FILE* fh;
	struct distribution c1[5];
	strcpy(c1[0].supcode, "CT"); 
	c1[0].dist_quantity = 0;
	strcpy(c1[1].supcode, "HS");
	c1[1].dist_quantity = 0;
	strcpy(c1[2].supcode, "FM"); 
	c1[2].dist_quantity = 0;
	strcpy(c1[3].supcode, "OM"); 
	c1[3].dist_quantity = 0;
	strcpy(c1[4].supcode, "SM"); c1[4].dist_quantity = 0;

	fh = fopen("dist.txt", "w");
	fprintf(fh, "%s\n%f", c1[0].supcode, c1[0].dist_quantity);
	fprintf(fh, "\n%s\n%f", c1[1].supcode, c1[1].dist_quantity);
	fprintf(fh, "\n%s\n%f", c1[2].supcode, c1[2].dist_quantity);
	fprintf(fh, "\n%s\n%f", c1[3].supcode, c1[3].dist_quantity);
	fprintf(fh, "\n%s\n%f", c1[4].supcode, c1[4].dist_quantity);
	fclose(fh);

}

void distupdate() {
	struct distribution b1[5];
	char update_item[3];
	float dist_item;
	int i, j, k;
	FILE* f;
	f = fopen("dist.txt", "r");


	while (!feof(f)) {
		fscanf(f, "%s\n%f", &b1[0].supcode, &b1[0].dist_quantity);
		fscanf(f, "\n%s\n%f", &b1[1].supcode, &b1[1].dist_quantity);
		fscanf(f, "\n%s\n%f", &b1[2].supcode, &b1[2].dist_quantity);
		fscanf(f, "\n%s\n%f", &b1[3].supcode, &b1[3].dist_quantity);
		fscanf(f, "\n%s\n%f", &b1[4].supcode, &b1[4].dist_quantity);


		printf("\nEnter item code to update it: ");
		scanf("%s", &update_item);
		printf("%s\n", update_item);
		if (strcmp(b1[0].supcode, update_item) == 0) {
			printf("How many items have been distributed (in millions) to hospitals?:\n");
			scanf("%f", &dist_item);
			b1[0].dist_quantity = b1[0].dist_quantity + dist_item;
			printf("Quantity distributed is %.2f", b1[0].dist_quantity);
		}
		else if (strcmp(b1[1].supcode, update_item) == 0) {
			printf("How many items have been distributed (in millions) to hospitals?:\n");
			scanf("%f", &dist_item);
			b1[1].dist_quantity = b1[1].dist_quantity + dist_item;
			printf("Quantity available is%.2f", b1[1].dist_quantity);
		}
		else if (strcmp(b1[2].supcode, update_item) == 0) {
			printf("How many items have been distributed (in millions) to hospitals?:\n");
			scanf("%f", &dist_item);
			b1[2].dist_quantity = b1[2].dist_quantity + dist_item;
			printf("Quantity available is%.2f", b1[2].dist_quantity);
		}
		else if (strcmp(b1[3].supcode, update_item) == 0) {
			printf("How many items have been distributed (in millions) to hospitals?:\n");
			scanf("%f", &dist_item);
			b1[3].dist_quantity = b1[3].dist_quantity + dist_item;
			printf("Quantity available is%.2f", b1[3].dist_quantity);
		}
		else if (strcmp(b1[4].supcode, update_item) == 0) {
			printf("How many items have been distributed (in millions) to hospitals?:\n");
			scanf("%f", &dist_item);
			b1[4].dist_quantity = b1[4].dist_quantity + dist_item;
			printf("Quantity available is%.2f", b1[4].dist_quantity);
		}
		else {
			printf("Invalid Input");
		}

		fclose(f);
		f = fopen("dist.txt", "w");

		fprintf(f, "%s\n%f", b1[0].supcode, b1[0].dist_quantity);
		fprintf(f, "\n%s\n%f", b1[1].supcode, b1[1].dist_quantity);
		fprintf(f, "\n%s\n%f", b1[2].supcode, b1[2].dist_quantity);
		fprintf(f, "\n%s\n%f", b1[3].supcode, b1[3].dist_quantity);
		fprintf(f, "\n%s\n%f", b1[4].supcode, b1[4].dist_quantity);
		fclose(f);

		fclose(f);
		break;
	}
}
 
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- FUNCTION: DISPLAY DONATIONS =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

void displaydonations(){
	donations h1;
	FILE* fp = fopen("donations.txt", "r");
	while (fread(&h1, sizeof(donations), 1, fp))
		printf("%-40s%-20s%-20s%-20d%-20f\n", h1.supname, h1.supcode, h1.donator,h1.no_shipment,h1.quantity_received);
}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- FUNCTION: SORT INVENTORY =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

void sortdonations()
{
    donations* b, b1;
    FILE* f = fopen("donations.txt", "r");
    fseek(f, 0, SEEK_END);
    int n = ftell(f)/sizeof(donations);
    int i,j;
    b = (donations*)calloc(n, sizeof(donations));
    rewind(f);
    for (i = 0; i < n; i++)
    {
        fread(&b[i], sizeof(donations), 1, f);
    }
    for (i = 0; i < n; i++)
    {
        for (j = i; j < n; j++) {
            if (b[i].quantity_received < b[j].quantity_received) {
                b1 = b[i];
                b[i] = b[j];
                b[j] = b1;
            }
        }
    }
    for (i = 0; i < n; i++) {
        printf("%-40s%-20s%-20s%-20d%-20f\n",b[i].supname, b[i].supcode, b[i].donator, b[i].no_shipment, b[i].quantity_received);
    }

    fclose(f);

}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- MAIN MENU =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

int main() {
	int choice;
	do {
		printf("\n1) Create record");
		printf("\n2) Display Donations");
		printf("\n3) Update donation quantity");
		printf("\n4) Search donation");
		printf("\n5) Sort inventory");
		printf("\n6) Create/ Edit distribution quantities");
		printf("\n0) Exit");
		printf("\nEnter your choice: ");
		scanf("%d", &choice);

		switch (choice) {
			case 1:
				createrecord();
				break;
			case 2:
				displaydonations();
				break;
			case 3:
				update_donation();
				break;
			case 4:
				searchdonation();
				break;
			case 5:
				sortdonations();
				break;
			case 6:
				distcreate();
				distupdate();
				break;
			case 0: printf("\nThank you for using our COVID 19 donation system!\n");
		}
	} while (choice!= 0);
}